clc;
clear;

point_num = 35;
P_S = randn(3,point_num)*2 + randn(3,point_num)*2;


R_SW = [ 0.99015653, -0.09001756,  0.10717691;
         0.10717691,  0.98012199, -0.16695508;
        -0.09001756,  0.17679855,  0.98012199];

t_S = [-0.562109, 1.41947194, 0.58107842]';





% P_W=R_SW'*P_S+t_S;

for i = 1:point_num
        %声呐坐标系中坐标
        P_W(:,i)=R_SW'*P_S(:,i)+t_S;
        
        %距离信息
        d(i) = norm(P_S(:,i),2);
    
        %方位角信息
        cos_theta(i)=P_S(1,i)/norm(P_S(1:2,i),2);
        sin_theta(i)=P_S(2,i)/norm(P_S(1:2,i),2);
        tan_theta_ture(i) =  sin_theta(i)/cos_theta(i);
        theta_true(i)= atan(tan_theta_ture(i));

        P_SI(1,i) = d(i)*cos_theta(i);
        P_SI(2,i) = d(i)*sin_theta(i);

end

% d = vecnorm(P_S);
% tan_theta = P_S(2,:)./P_S(1,:);
% theta_est = atan(tan_theta);
% P_SI(1,:) = d.*cos(theta_est);
% P_SI(2,:) = d.*sin(theta_est);



[ R_sw_my,t_s_my] = compute_t_R(P_W, P_SI,0,0);
disp('t_s_my:');
disp(t_s_my);
disp('R_sw_my:');
disp(R_sw_my);

[ R_sw_nonapp,t_s_nonapp] = Wang_nonapp_algorithm_2(P_W, P_SI);
disp('t_s_nonapp:');
disp(t_s_nonapp);
disp('R_sw_nonapp:');
disp(R_sw_nonapp);

t_s_true = -R_SW*t_S;
[ R_sw_app,t_s_app] = Wang_app_algorithm_2( P_SI,P_W, t_s_true ,0);
disp('t_s_app:');
disp(t_s_app);
disp('R_sw_app:');
disp(R_sw_app);